# Chatbot with TensorFlow 2.0 

A chatbot that can be used for recruitment of pirates all around the world - Going Merry.
The same model can be used for creating chatbots for any type of organizations.

<img src = "https://cdn-images-1.medium.com/max/800/1*SAHhdvu3v9l81OjsfBa_Yw.jpeg" />

## Thank You
